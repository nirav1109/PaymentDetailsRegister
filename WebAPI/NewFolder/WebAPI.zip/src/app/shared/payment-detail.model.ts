export class PaymentDetail {
    pmId !:number;
    cardOwnerName!: string;
    cardNumber!: string;
    expirationDate!: string;
    cvv!: string;
}